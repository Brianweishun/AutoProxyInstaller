﻿function getData(URL, na_token) {
    return new Promise(function (resolve, reject) {
        let req = new XMLHttpRequest();
        req.open('GET', URL, true);
        req.setRequestHeader('Content-Type', 'application/json');
        req.setRequestHeader('Authorization', 'Bearer ' + na_token);
        req.onload = function () {
            if (req.status === 200) {
                resolve(req.responseText);
            }
            else {
                reject(new Error(req.statusText));
            }
        };
        req.onerror = function () {
            reject(new Error((req.statusText)));
        };
        req.send();
    });
}

function getData(URL) {
    return new Promise(function (resolve, reject) {
        let req = new XMLHttpRequest();
        req.open('GET', URL, true);
        req.setRequestHeader('Content-Type', 'application/json');
        req.onload = function () {
            if (req.status === 200) {
                resolve(req.responseText);
            }
            else {
                reject(new Error(req.statusText));
            }
        };
        req.onerror = function () {
            reject(new Error((req.statusText)));
        };
        req.send();
    });
}

function getHtml(URL) {
    return new Promise(function (resolve, reject) {
        let req = new XMLHttpRequest();
        req.open('GET', URL, true);
        req.setRequestHeader('Content-Type', 'text/html; charset=UTF-8');
        req.onload = function () {
            if (req.status === 200) {
                resolve(req.responseText);
            }
            else {
                reject(new Error(req.statusText));
            }
        };
        req.onerror = function () {
            reject(new Error((req.statusText)));
        };
        req.send();
    });
}

function wait(ms, value) {
    return new Promise(resolve => setTimeout(resolve, ms, value));
}

function sleeper(ms) {
    return function (x) {
        return new Promise(resolve => setTimeout(() => resolve(x), ms));
    };
}

function delay(ms, value) {
    return new Promise(function (resolve, reject) {
        setTimeout(function () {
            resolve(value);
        }, ms);
    });
}

function postData(URL, post_data) {
    return new Promise(function (resolve, reject) {
        let req = new XMLHttpRequest();
        req.open('POST', URL, true);
        req.setRequestHeader('Content-Type', 'application/json');
        req.onload = function () {
            if (req.status === 200) {
                resolve(req.responseText);
            }
            else {
                reject(new Error(req.statusText));
            }
        };
        req.onerror = function () {
            reject(new Error((req.statusText)));
        };
        req.send(post_data);
    });
}
