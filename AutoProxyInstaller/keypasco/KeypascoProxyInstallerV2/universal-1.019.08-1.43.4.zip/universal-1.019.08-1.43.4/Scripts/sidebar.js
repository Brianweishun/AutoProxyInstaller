﻿let addflag = false;
let editflag = false;
//編輯
function app_edit_onclick(obj,event) {
    event.stopPropagation();
    editflag = true;
    console.log(obj);
    let linkButton = obj.closest('.linkbutton');
    let rowListDiv = linkButton.closest('.rowlist');
    let index = Array.from(rowListDiv.children).indexOf(linkButton);
    //取得linkButton屬性直內容
    let appid = linkButton.dataset.appid;
    let userid = linkButton.dataset.userid;
    let appname = linkButton.dataset.appname;
    let logofileid = linkButton.dataset.logofileid;
    let descript = linkButton.dataset.descript;
    let accountid = linkButton.dataset.account_id;
    let created = linkButton.dataset.created;
    let apptype = linkButton.dataset.type;
    let redirect_url = linkButton.dataset.redirectUrl;
    let subject = linkButton.dataset.subject;
    let expire_time = linkButton.dataset.expireTime;
    console.log(linkButton);
    console.log(`第 ${index + 1} 個 div 被點擊了`);
    // 取得當前 linkButton 中的內容
    let content = linkButton.querySelector('.imagetextarea p').innerText;
    hide_Deletebutton();
    visible_webappkeysbutton(true);
    //圖形初始化
    document.querySelector('.IconSelector').removeAttribute('style');
    // 設置於 id = AppName 的 input 欄位
    document.getElementById('AppID').value = appid;
    document.getElementById('UserID').value = userid;
    document.getElementById('AppName').value = appname;
    document.getElementById('LogoFileID').value = logofileid;
    document.getElementById('Description').value = descript;
    document.getElementById('AccountID').value = accountid;
    document.getElementById('Created').value = created;
    document.getElementById('SignOnRedirectURL').value = redirect_url;
    document.getElementById('SignOnSubject').value = subject;

    set_expire_time_data(expire_time);
    set_expire_time_to_ui();

    linkButton.classList.add('selected');
    document.getElementById('sidebar').style.right = '0';
    document.getElementById('overlay').style.display = 'block';

    var selector = document.getElementById('AppType');
    for (let i = 0; i < selector.options.length; i++) {
        // 檢查當前 option 是否與傳入的 value 相符
        if (selector.options[i].value === apptype) {
            // 相符的設為選中
            selector.options[i].selected = true;
        } else {
            // 不相符的移除選中狀態
            selector.options[i].selected = false;
        }
    }

    select_app_type(apptype);

    var url = "/FileStorage/DownloadLogoID?FileId=" + logofileid;
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }

            return response.text();
        })
        .then(data => {
            let icon_selector = document.querySelector('.IconSelector');
            icon_selector.style.backgroundSize = icon_selector.offsetWidth.toString() + "px " + icon_selector.offsetHeight.toString() + "px";
            icon_selector.style.backgroundImage = 'url(' + data + ')';
        })
        .catch(error => {
            // 處理錯誤
            console.error('There was a problem with the fetch operation:', error);
        });
}

// 新增按鈕追加點擊事件
function AddClickEvent() {
    document.getElementById('add').addEventListener('click', function () {
        addflag = true;
        resetvalue();
        hide_Deletebutton();
        visible_webappkeysbutton(false);
        //圖形初始化
        document.querySelector('.IconSelector').removeAttribute('style');

        document.getElementById('sidebar').style.right = '0';
        document.getElementById('overlay').style.display = 'block';
    });
}

function minutesToTimeString(minutes) {
    let hours = Math.floor(minutes / 60);
    let mins = minutes % 60;
    return hours.toString() + ":" + mins.toString();
}

function timeStringToMinutes(timeString) {
    let [hours, mins] = timeString.split(":").map(Number);
    return hours * 60 + mins;
}

function confirmbutton() {
    let account_id_input = document.querySelector('#AccountID');
    let app_name_input = document.querySelector('#AppName');
    let account_id = account_id_input.value.trim();
    let app_name = app_name_input.value.trim();

    // 檢查 AccountID 和 AppName 是否為空值或空白
    if (!app_name) {
        open_info_messagebox("Error","App name Can't be null");
        return;
    }
    if (addflag == true) {

        let post_url;

        let app_type = document.querySelector('#AppType').value;

        if (app_type == "webapp") {
            post_url = "/WebApp/AddWebAppApp";

            let logo_file_id = document.querySelector('#LogoFileID').value;
            let user_id = document.querySelector('#UserID').value;
            let description = document.querySelector('#Description').value;
            let app_name_input = document.querySelector('#AppName');
            let app_name = app_name_input.value;

            let redirect_url = document.querySelector('#SignOnRedirectURL').value;
            let subject = document.querySelector('#SignOnSubject').value;

            var group = document.querySelector('#SelectExpireTimeGroup');
            var hours_element_data = group.querySelector('.ExpireTimeHours').value;
            var mins_element_data = group.querySelector('.ExpireTimeMinutes').value;

            let expire_time = timeStringToMinutes(hours_element_data + ':' + mins_element_data);

            post_data = {
                "AppName": app_name.toString(),
                "Type": app_type.toString(),
                "LogoFileID": logo_file_id.toString(),
                "UserID": user_id.toString(),
                "Description": description.toString(),
                "RedirectURL": redirect_url.toString(),
                "Subject": subject.toString(),
                "ExpireTime": expire_time
            };
        }
        else {
            post_url = "/WebApp/AddApp";

            let logo_file_id = document.querySelector('#LogoFileID').value;
            let user_id = document.querySelector('#UserID').value;
            let description = document.querySelector('#Description').value;
            let account_id_input = document.querySelector('#AccountID');
            let account_id = account_id_input.value;
            let app_name_input = document.querySelector('#AppName');
            let app_name = app_name_input.value;

            post_data = {
                "AppName": app_name.toString(),
                "Type": app_type.toString(),
                "LogoFileID": logo_file_id.toString(),
                "UserID": user_id.toString(),
                "AccountID": account_id.toString(),
                "SiteURL": siteurl.toString(),
                "Description": description.toString()
            };
        }

        var auth_bearer = 'Bearer ' + user_info['na_token'];
        fetch(post_url,
            {
                headers: {
                    "Authorization": auth_bearer,
                    'Content-Type': 'application/json'
                },
                method: "POST",
                body: JSON.stringify(post_data)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                console.log(data);
                if (data.result === 'success') {
                    document.querySelector('#AppID').value = data.Id.toString();
                    document.querySelector('#Created').value = data.Created.toString();
                    document.querySelector('#AppName').value = data.AppName;
                    document.querySelector('#LogoFileID').value = data.LogoFileID;
                    document.querySelector('#Description').value = data.Description;
                    document.querySelector('#UserID').value = data.UserID;
                    document.querySelector('#AppSite').value = data.SiteURL;
                    document.querySelector('#AccountID').value = data.AccountID;

                    // 計算現有的 rowlist 數量
                    const rowLists = document.querySelectorAll('#group .rowlist');
                    let lastRowList = rowLists[rowLists.length - 1];

                    //rowlist 不存在時或者內部div多於5個時,執行以下
                    if (!lastRowList || lastRowList.children.length >= 5) {
                        AppendDivMoreThan(lastRowList);
                    } else {
                        AppendDivLessThan();
                    }
                    //追加新的點擊事件
                    AddClickEvent();
                    addflag = false;

                    var url = "/FileStorage/DownloadLogoID?FileId=" + data.LogoFileID;
                    fetch(url)
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok ' + response.statusText);
                            }

                            return response.text();
                        })
                        .then(data => {
                            let app_id = document.querySelector('#AppID').value;
                            let query_str = '[data-appid="{app_id}"]';
                            query_str = query_str.replace("{app_id}", app_id);
                            let element = document.querySelector(query_str);
                            let imageAreaDiv = element.querySelector('.imagearea');

                            const logo = document.createElement('img');
                            let img_id = "logo-" + app_id;
                            let img_data = data;
                            logo.setAttribute("style", "width:85px; height: 85px;");
                            logo.classList.add(img_id);
                            logo.setAttribute("src", img_data);
                            imageAreaDiv.appendChild(logo);
                            resetvalue();
                            document.getElementById('sidebar').style.right = '-350px';
                            document.getElementById('overlay').style.display = 'none';
                        })
                        .catch(error => {
                            // 處理錯誤
                            console.error('There was a problem with the fetch operation:', error);
                        });
                }
                else {
                    console.log(data);
                }
            })
            .catch(error => {
                // 處理錯誤
                console.error('There was a problem with the fetch operation:', error);
            });

    }
    else if (editflag == true)
    {
        // 取得 input 的值
        let appNameValue = document.getElementById('AppName').value;
        let selectedDiv = document.querySelector('.linkbutton.linkbox.selected');
        if (selectedDiv) {
            let app_type = document.querySelector('#AppType').value;
            let app_id = document.querySelector('#AppID').value;
            let logo_file_id = document.querySelector('#LogoFileID').value;
            let user_id = document.querySelector('#UserID').value;
            let siteurl = document.querySelector('#AppSite').value;
            let description = document.querySelector('#Description').value;
            let account_id_input = document.querySelector('#AccountID');
            let account_id = account_id_input.value;
            let app_name_input = document.querySelector('#AppName');
            let app_name = app_name_input.value;

            let redirect_url = document.querySelector('#SignOnRedirectURL').value;
            let subject = document.querySelector('#SignOnSubject').value;

            

            var group = document.querySelector('#SelectExpireTimeGroup');
            var hours_element_data = group.querySelector('.ExpireTimeHours').value;
            var mins_element_data = group.querySelector('.ExpireTimeMinutes').value;

            let expire_time = timeStringToMinutes(hours_element_data + ':' + mins_element_data);

            let post_data;
            let url;

            if (app_type == 'webapp') {
                url = "/WebApp/ModifyWebAppApp";
                post_data = {
                    "AppID": app_id.toString(),
                    "AppName": app_name.toString(),
                    "LogoFileID": logo_file_id.toString(),
                    "UserID": user_id.toString(),
                    "Subject": subject.toString(),
                    "RedirectURL": redirect_url.toString(),
                    "ExpireTime": expire_time,
                    "Description": description.toString()
                };
            }
            else {
                url = "/WebApp/ModifyApp";
                post_data = {
                    "AppID": app_id.toString(),
                    "Type": app_type.toString(),
                    "AppName": app_name.toString(),
                    "LogoFileID": logo_file_id.toString(),
                    "UserID": user_id.toString(),
                    "AccountID": account_id.toString(),
                    "SiteURL": siteurl.toString(),
                    "Description": description.toString()
                };
            }

            var auth_bearer = 'Bearer ' + user_info['na_token'];
            fetch(url,
                {
                    headers: {
                        "Authorization": auth_bearer,
                        'Content-Type': 'application/json'
                    },
                    method: "POST",
                    body: JSON.stringify(post_data)
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok ' + response.statusText);
                    }
                    return response.json();
                })
                .then(data => {
                    console.log(data);
                    if (data.result === 'success') {
                        // 獲取 class 為 imagetextarea 的 div
                        let imageTextArea = selectedDiv.querySelector('.imagetextarea');
                        if (imageTextArea) {
                            // 獲取 <p> 標籤
                            let pTag = imageTextArea.querySelector('p');
                            if (pTag) {
                                // 設定 <p> 標籤的內部文字
                                pTag.textContent = appNameValue;
                            }
                        }
                        selectedDiv.setAttribute('data-appname', app_name);
                        selectedDiv.setAttribute('data-type', app_type);
                        selectedDiv.setAttribute('data-siteurl', siteurl);
                        selectedDiv.setAttribute('data-userid', user_id);
                        selectedDiv.setAttribute('data-account_id', account_id);
                        selectedDiv.setAttribute('data-logofileid', logo_file_id);
                        selectedDiv.setAttribute('data-redirect-url', redirect_url);
                        selectedDiv.setAttribute('data-subject', subject);
                        selectedDiv.setAttribute('data-expire-time', expire_time);
                        selectedDiv.classList.remove('selected');
                        editflag = false;

                        var url = "/FileStorage/DownloadLogoID?FileId=" + data.LogoFileID;
                        fetch(url)
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error('Network response was not ok ' + response.statusText);
                                }

                                return response.text();
                            })
                            .then(data => {
                                let app_id = document.querySelector('#AppID').value;
                                let query_str = '[data-appid="{app_id}"]';
                                query_str = query_str.replace("{app_id}", app_id);
                                let element = document.querySelector(query_str);
                                let imageAreaDiv = element.querySelector('.imagearea');

                                const logo = imageAreaDiv.querySelector('img');
                                let img_id = "logo-" + app_id;
                                let img_data = data;
                                logo.setAttribute("style", "width:85px; height: 85px;");
                                logo.classList.add(img_id);
                                logo.setAttribute("src", img_data);
                                imageAreaDiv.appendChild(logo);
                                resetvalue();
                            })
                            .catch(error => {
                                // 處理錯誤
                                console.error('There was a problem with the fetch operation:', error);
                            });
                    }
                    else {
                        console.log(data);
                    }
                })
                .catch(error => {
                    // 處理錯誤
                    console.error('There was a problem with the fetch operation:', error);
                });
        }
        document.getElementById('sidebar').style.right = '-350px';
        document.getElementById('overlay').style.display = 'none';
    } else {
        resetvalue();
        document.getElementById('sidebar').style.right = '-350px';
        document.getElementById('overlay').style.display = 'none';
    }
}
/*1 rowlist 內button數少於目標個數時的處理 */
function AppendDivLessThan() {
    // 找到最後一個 rowlist
    let latestRowList = document.querySelectorAll('#group .rowlist');
    let lastRowList = latestRowList[latestRowList.length - 1];

    //創建linkButton
    let linkButton = document.createElement('div');
    linkButton.className = 'linkbutton';
    linkButton.classList.add('linkbox');
    linkButton.setAttribute('data-appid', document.getElementById('AppID').value);
    linkButton.setAttribute('data-appname', document.getElementById('AppName').value);
    linkButton.setAttribute('data-account_id', document.getElementById('AccountID').value);
    linkButton.setAttribute('data-logofileid', document.getElementById('LogoFileID').value);
    linkButton.setAttribute('data-descript', document.getElementById('Description').value);
    linkButton.setAttribute('data-redirect-url', document.getElementById('SignOnRedirectURL').value);
    linkButton.setAttribute('data-subject', document.getElementById('SignOnSubject').value);
    linkButton.setAttribute('data-userid', document.getElementById('UserID').value);
    linkButton.setAttribute('data-created', document.getElementById('Created').value);
    linkButton.setAttribute('onclick', 'app_herf_onclick(this)');

    var group = document.querySelector('#SelectExpireTimeGroup');
    var hours_element_data = group.querySelector('.ExpireTimeHours').value;
    var mins_element_data = group.querySelector('.ExpireTimeMinutes').value;

    let expire_time = timeStringToMinutes(hours_element_data + ':' + mins_element_data);

    linkButton.setAttribute('data-expire-time', expire_time);
    //創建editButton
    let editButton = document.createElement('div');
    editButton.className = 'editbutton';
    editButton.setAttribute('onclick', 'app_edit_onclick(this,event)');
    let label = document.createElement('label');
    label.className = 'form-label';
    label.innerText = '···';
    editButton.appendChild(label);
    //創建imageArea
    let imageArea = document.createElement('div');
    imageArea.className = 'imagearea';
    //創建imageTextArea
    let imageTextArea = document.createElement('div');
    imageTextArea.className = 'imagetextarea';
    let paragraph = document.createElement('p');
    paragraph.innerText = document.getElementById('AppName').value;
    imageTextArea.appendChild(paragraph);

    linkButton.appendChild(editButton);
    linkButton.appendChild(imageArea);
    linkButton.appendChild(imageTextArea);
    // 在最後一個 rowlist 中追加 linkButton
    lastRowList.appendChild(linkButton);

    // 刪除舊的addlinkButton
    let oldAddlinkButton = document.getElementById('add');
    if (oldAddlinkButton) {
        oldAddlinkButton.remove();
    }

    // 在目標rowlist中重新追加新的addlinkButton
    let newAddlinkButton = document.createElement('div');
    newAddlinkButton.id = 'add';
    newAddlinkButton.className = 'addlinkbutton';
    let addContent = document.createElement('h1');
    addContent.innerText = '+';
    newAddlinkButton.appendChild(addContent);
    lastRowList.appendChild(newAddlinkButton);

}
/*1 row 內button數多於目標個數時的處理 */ 
function AppendDivMoreThan(lastRowList) {
    // 刪除舊的addlinkButton
    let oldAddlinkButton = document.getElementById('add');
    if (oldAddlinkButton) {
        oldAddlinkButton.remove();
    }

    //創建linkButton
    let linkButton = document.createElement('div');
    linkButton.className = 'linkbutton';
    linkButton.classList.add('linkbox');
    linkButton.setAttribute('data-appid', document.getElementById('AppID').value);
    linkButton.setAttribute('data-appname', document.getElementById('AppName').value);
    linkButton.setAttribute('data-account_id', document.getElementById('AccountID').value);
    linkButton.setAttribute('data-logofileid', document.getElementById('LogoFileID').value);
    linkButton.setAttribute('data-descript', document.getElementById('Description').value);
    linkButton.setAttribute('data-redirect-url', document.getElementById('SignOnRedirectURL').value);
    linkButton.setAttribute('data-subject', document.getElementById('SignOnSubject').value);
    linkButton.setAttribute('data-userid', document.getElementById('UserID').value);
    linkButton.setAttribute('data-created', document.getElementById('Created').value);

    var group = document.querySelector('#SelectExpireTimeGroup');
    var hours_element_data = group.querySelector('.ExpireTimeHours').value;
    var mins_element_data = group.querySelector('.ExpireTimeMinutes').value;
    let expire_time = timeStringToMinutes(hours_element_data + ':' + mins_element_data);
    linkButton.setAttribute('data-expire-time', expire_time);

    let selector = document.getElementById('AppType');
    let selectedOption = selector.options[selector.selectedIndex];
    linkButton.setAttribute('data-type', selectedOption.value);
    //創建editButton
    let editButton = document.createElement('div');
    editButton.className = 'editbutton';
    editButton.setAttribute('onclick', 'app_edit_onclick(this,event)');
    let label = document.createElement('label');
    label.className = 'form-label';
    label.innerText = '···';
    editButton.appendChild(label);
    //創建imageArea
    let imageArea = document.createElement('div');
    imageArea.className = 'imagearea';
    //創建imageTextArea
    let imageTextArea = document.createElement('div');
    imageTextArea.className = 'imagetextarea';
    let paragraph = document.createElement('p');
    paragraph.innerText = document.getElementById('AppName').value;;
    imageTextArea.appendChild(paragraph);

    linkButton.appendChild(editButton);
    linkButton.appendChild(imageArea);
    linkButton.appendChild(imageTextArea);
    //rowlist是否存在
    if (!lastRowList) {
        lastRowList = document.createElement('div');
        lastRowList.classList.add('rowlist');
        lastRowList.classList.add('addlist-row');
        document.getElementById('group').appendChild(lastRowList);
    }
    // 在最後一個rowlist中追加linkButton 
    lastRowList.appendChild(linkButton);

    // 在 id = group 下面追加一個新的rowlist
    let newRowList = document.createElement('div');
    newRowList.classList.add('rowlist');
    newRowList.classList.add('addlist-row');
    document.getElementById('group').appendChild(newRowList);

    // 在新的rowlist中重新追加新的addlinkButton
    let newAddlinkButton = document.createElement('div');
    newAddlinkButton.id = 'add';
    newAddlinkButton.className = 'addlinkbutton';

    let addContent = document.createElement('h1');
    addContent.innerText = '+';
    newAddlinkButton.appendChild(addContent);
    newRowList.appendChild(newAddlinkButton);

}

//刪除按鈕
function app_delete() {
    // 獲取選擇的按鈕
    let selectedButton = document.querySelector('.linkbutton.linkbox.selected');

    if (selectedButton) {
        let DeleteID = selectedButton.getAttribute("data-appid");
        var url = "/WebApp/DeleteApp?id=" + DeleteID;
        var auth_bearer = 'Bearer ' + user_info['na_token'];

        fetch(url, {
            method: "GET",
            headers: {
                "Authorization": auth_bearer,
                'Content-Type': 'application/json'
            }
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                // 解析回應的JSON內容
                return response.json();
            })
            .then(data => {
                if (data["result"] === "success") {
                    // 獲取選擇linkButton當前所在的rowlist
                    let nowRowList = selectedButton.closest('.rowlist');

                    // 移除選擇按鈕
                    selectedButton.remove();
                    moveDivToParent(nowRowList);
                    resetvalue();
                    bootstrap.Modal.getInstance(document.getElementById('DeleteMessageBox')).hide();
                    document.getElementById('sidebar').style.right = '-350px';
                    document.getElementById('overlay').style.display = 'none';

                }
                else {
                    console.log(data);
                }
            })
            .catch(error => {
                console.error('There was a problem with the fetch operation:', error);
            });
    }
}
/* 全體按鈕位置調整*/
function moveDivToParent(nowRowList) {
    // 獲取下一個rowList
    let nextRowList = nowRowList.nextElementSibling;
    // 獲取當前rowList的linkButton
    let nowRowlistContent = nowRowList.querySelector('div');
    if (!(nextRowList === null) && nowRowlistContent) {
        //獲取下個rowList中的第一個linkButton
        let firstlinkButton = nextRowList.querySelector('div:first-child');
        if (!(firstlinkButton === null)) {
            // 將下一個rowlist中的第一個linkButton 移動到當前的rowlist裡
            nowRowList.appendChild(nextRowList.querySelector('div:first-child'));
            // 重新找尋下一層中是否還有div
            if (nextRowList.querySelector('div:first-child') === null) {
                nextRowList.remove();
                return;
            }
            moveDivToParent(nextRowList);
        }
    }
}
//初始化欄位數值
function resetvalue() {
    document.getElementById('AppID').value = "";
    document.getElementById('AppName').value = "";
    document.getElementById('AccountID').value = "";
    document.getElementById('LogoFileID').value = "";
    document.getElementById('Description').value = "";
    document.getElementById('UserID').value = "";
    document.getElementById('AppSite').value = "";
    document.getElementById('Created').value = "";
    document.getElementById('SignOnSubject').value = "";
    document.getElementById('SignOnRedirectURL').value = "";
    set_expire_time_data(15);
    select_app_type('webapp');
}

//
function visible_webappkeysbutton(show) {
    let button = document.querySelector('.web-app-keys-button');
    if(show === true)
        button.classList.remove('invisible');
    else
        button.classList.add('invisible');
}

//刪除按鈕隱藏
function hide_Deletebutton() {
    let displaydom = document.getElementById('delete_btn');
    if (addflag) {
        displaydom.style.display = 'none';
    } else {
        displaydom.style.display = 'block';
    }
}