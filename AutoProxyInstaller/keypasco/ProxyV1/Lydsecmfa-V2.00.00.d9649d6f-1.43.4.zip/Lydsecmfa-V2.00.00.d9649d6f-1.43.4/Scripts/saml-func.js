var vpnModal = null;

function isIE() {
    if (!!window.ActiveXObject || "ActiveXObject" in window) {
        return true;
    }
    else {
        return false;
    }
}

function generate_data() {
    var a = new Object();
    a["star@local"] = "star";
    a["star@addomain[AD]"] = "star";
    a["star@lydsec.com[LDAP]"] = "star";
    localStorage.setItem("saml_account_list", JSON.stringify(a));
}

function class_list_remove(element, item) {
    if ((element === null) || (element === undefined))
        return;

    if (isIE() === true) {
        var classes = element.className;
        var re = new RegExp(item);
        if (re.test(classes) === true) {
            classes = classes.replace(item, '');
            element.className = classes;
        }
    }
    else {
        if ((element !== null) && (element !== undefined) && (element.classList !== null) && (element.classList !== undefined) && (item !== null) && (item !== undefined)) {
            if (element.classList.contains(item) === true) {
                element.classList.remove(item);
            }
        }
    }
}

function class_list_add(element, item) {
    if ((element === null) || (element === undefined))
        return;

    if (isIE() === true) {
        var classes = element.className;
        var re = new RegExp(item);
        if (re.test(classes) === false) {
            classes = item + ' ' + classes;
            element.className = classes;
        }
    }
    else {
        if ((element !== null) && (element !== undefined) && (element.classList !== null) && (element.classList !== undefined) && (item !== null) && (item !== undefined)) {
            if (element.classList.contains(item) === false) {
                element.classList.add(item);
            }
        }
    }
}

var SamlLanguage = (function () {
    var instance;
    return function () {
        if (typeof instance === 'object') return instance;
        this.p = 'public'
        instance = this;
    }
}())

function get_languages() {
    var langs = ['en', 'jp', 'zh-tc', 'zh-sc'];

    var saml_lang = new SamlLanguage();
    if ((saml_lang.select_lang === null) || (saml_lang.select_lang === undefined)) {
        saml_lang.select_lang = 'zh-tc';
    }
    if ((saml_lang.lang_status === null) || (saml_lang.lang_status === undefined)) {
        saml_lang.lang_status = new Object();

        for (var i = 0; i < langs.length; i++) {
            var lang = langs[i];
            saml_lang.lang_status[lang] = 'unknow';
        }
    }

    for (var i = 0; i < langs.length; i++) {
        var lang = langs[i];
        get_language(lang);
    }
}

function got_language_handler(evt) {
    var xhr = evt.target;
    if (xhr.status === 200) {
        var raw_data = xhr.responseText;
        raw_data = raw_data.replace(/(\/\*[^*]*\*\/)|(\/\/[^*]*)/g, '');
        var saml_lang = new SamlLanguage();
        lang_data = JSON.parse(raw_data);

        var lang = Object.keys(lang_data)[0];

        if ((saml_lang.languages === undefined) || (saml_lang.languages === null)) {
            saml_lang.languages = new Object();
        }

        if ((saml_lang.select_lang === undefined) || (saml_lang.select_lang === null)) {
            saml_lang.select_lang = lang;
        }

        saml_lang.languages[lang] = lang_data[lang];

        if ((saml_lang.lang_status === undefined) || (saml_lang.lang_status === null)) {
            saml_lang.lang_status = new Object();
        }

        saml_lang.lang_status[lang] = 'done';
    }
}

function get_language(lang) {

    var url = "";
    switch (lang) {
        case 'en':
            url = '/Saml/Content/LangEn';
            break;
        case 'jp':
            url = '/Saml/Content/LangJp';
            break;
        case 'zh-tc':
            url = '/Saml/Content/LangZhTc';
            break;
        case 'zh-sc':
            url = '/Saml/Content/LangZhSc';
            break;
        default:
            url = '/Saml/Content/LangEn';
    }

    var saml_lang = new SamlLanguage();
    if ((saml_lang.lang_status === undefined) || (saml_lang.lang_status === null)) {
        saml_lang.lang_status = new Object();
    }
    else {
        var status = saml_lang.lang_status[lang];
        if ((status !== undefined) && (status !== null) && (status === 'done')) {
            return;
        }
    }

    saml_lang.lang_status[lang] = 'downloading';

    var req = new XMLHttpRequest();
    req.open('GET', url, true);
    req.addEventListener('load', got_language_handler, false);
    req.setRequestHeader('Content-Type', 'application/json');
    req.send();
}

function page_switch(to_page) {
    //var pages = ["multi_login_page", "multi_pass_word_page", "user_page", "waiting_device_checking_page", "fido2_user_page", "waiting_fido2_sign_page", "waiting_qrcode_page", "pass_word_page", "select_account_page", "edit_account_menu_page", "waiting_sign_page", "result_fail_page", "result_success_page", "error_page"];
    var pages = ["multi_login_page", "multi_pass_word_page", "user_page", "waiting_device_checking_page", "fido2_user_page", "waiting_fido2_sign_page", "waiting_qrcode_page", "pass_word_page", "select_account_page", "edit_account_menu_page", "waiting_sign_page", "result_fail_page", "result_success_page", "error_page", "forgot_to_bring_fido2_page"];
	for (var i = 0; i < pages.length; i++) {
		var page = pages[i];
		if (to_page === page) {
			var page_element = document.getElementById(page);
			page_element.style.display = "flex";
			class_list_add(page_element, 'd-flex');
			class_list_remove(page_element, 'd-none');
            //			class_list_remove(page_element, "invisible");
		}
		else {
			var page_element = document.getElementById(page);
			page_element.style.display = "none";
			class_list_remove(page_element, 'd-flex');
			class_list_add(page_element, 'd-none');
			//			class_list_add(page_element, "invisible");
		}
	}
}

function reloadCaptcha() {
    var req = new XMLHttpRequest();
    req.open('POST', '/AppReg/GenerateCaptcha', true);
    req.onload = function () {
        if (req.status === 200) {
            var data = req.responseText;
            var re = new RegExp('data:image/png;base64,');
            if (re.test(data) === true) {
                document.getElementById('captchaText').src = data;
            }
        }
        else {
            reject(new Error(req.statusText));
        }
    };
    req.onerror = function () {
        reject(new Error((req.statusText)));
    };
    req.send();
}

function reload_captcha_button_on_click() {
    reloadCaptcha();
}

function generate_account_list(accounts) {
    if ((accounts === null) || (accounts === undefined)) {
        return;
    }

    var myNode = document.getElementById("account_menu");
    while (myNode.firstChild) {
        myNode.removeChild(myNode.lastChild);
    }

    var keys = Object.keys(accounts);
    for (var i = 0; i < keys.length; i++) {
        var name = accounts[keys[i]];
        var login_name = keys[i];

        var button = document.createElement("button");
        button.setAttribute("class", "btn btn-primary text-start btn-account-menu");
        button.setAttribute("onclick", "account_menus_on_click(this);");
        button.setAttribute("data", login_name);
        var span_name = document.createElement("span");
        span_name.setAttribute("style", "color: #202224;font-size: 17px;font-family: 'Poppins';");
        span_name.textContent = name;
        var br = document.createElement("br");
        var span_login_name = document.createElement("span");
        span_login_name.setAttribute("style", "color: #959595;font-size: 15px;font-family: 'Poppins';");
        span_login_name.textContent = login_name;
        var div_line = document.createElement("div");
        div_line.setAttribute("style", "border-bottom: 1px solid #D1D1D1;background: #F2F2F2;");
        button.appendChild(span_name);
        button.appendChild(br);
        button.appendChild(span_login_name);
        document.getElementById("account_menu").appendChild(button);
        document.getElementById("account_menu").appendChild(div_line);

    }
}

function get_lang_data(key) {
    if ((language !== null) && (language !== undefined)) {
        if ((language !== null) && (language !== undefined) && (language[key] !== null) && (language[key] !== undefined)) {
            return language[key];
        }
    }

    return "";
}

function resize_use_another_button() {
    var button = document.getElementById('login_another_button');
    var span = button.querySelector('span');
    var img = button.querySelector('img');
    var left = (button.offsetWidth - span.offsetWidth - img.offsetWidth) / 4;
    img.style.marginLeft = left.toString() + 'px';
}

function update_ui_lang() {
    var saml_lang = new SamlLanguage();
    var langs = saml_lang.languages;
    if ((langs === undefined) || (langs === null)) {
        return;
    }

    langData = langs[saml_lang.select_lang];
    if ((langData === undefined) || (langData === null))
        return;

    var elements = document.querySelectorAll('[data-i18n]');
    for (var i = 0; i < elements.length; i++) {
        var element = elements[i];
        var key = element.getAttribute('data-i18n');
        if ((langData !== null) && (langData !== undefined) && (langData[key] !== null) && (langData[key] !== undefined)) {
            if ((element.getAttribute('placeholder') !== null) && (element.getAttribute('placeholder') !== undefined)) {
                element.setAttribute('placeholder', langData[key]);
            }
            else {
                element.textContent = langData[key];
            }
        }
    }

    var langs = ['en', 'zh-tc', 'zh-sc', 'jp'];
    for (var i = 0; i < langs.length; i++) {
        var lang = langs[i];
        if (lang === saml_lang.select_lang) {
            var name = 'vpn-modal-message-' + lang;
            var ele = document.getElementsByClassName(name)[0];
            ele.style.display = '';
        }
        else {
            var name = 'vpn-modal-message-' + lang;
            var ele = document.getElementsByClassName(name)[0];
            ele.style.display = 'none';
        }
    }

    var domain_select = document.getElementById('Domain');
    var options = domain_select.querySelectorAll('option');
    for (var i = 0; i < options.length; i++) {
        if (options[i].value === 'local') {
            options[i].textContent = langData['local-domain-name'];
            break;
        }
    }

    var lang_select_comboboxes = document.getElementsByClassName('select-lang-combobox');
    for (var j = 0; j < lang_select_comboboxes.length; j++) {
        var lang_select_combobox = lang_select_comboboxes[j];
        options = lang_select_combobox.querySelectorAll('option');
        for (var i = 0; i < options.length; i++) {
            if (options[i].value === saml_lang.select_lang) {
                lang_select_combobox.selectedIndex = i;
                break;
            }
        }
    }

    resize_use_another_button();
}

function load_language() {
    if ((localStorage === null) || (localStorage === undefined)) {
        console.log("LocalStorage not enable");
        return;
    }

    var saml_lang = localStorage.getItem("keypasco_saml_lang");
    if ((saml_lang === null) || (saml_lang === undefined)) {
        saml_lang = "en";
    }

    var lang = new SamlLanguage();
    lang.select_lang = saml_lang;

    localStorage.setItem("keypasco_saml_lang", saml_lang);

    update_ui_lang();
}

function downloaded_handler() {
    init_post();
}

function init() {
    //Test
    //generate_data();
    //

    var downloaded_event = document.createElement('input');
    downloaded_event.setAttribute('id', 'downloaded_event');
    downloaded_event.setAttribute('type', 'hidden');
    downloaded_event.setAttribute('onclick', 'downloaded_handler()');
    document.body.appendChild(downloaded_event);

    get_languages();

    var intervalID = setInterval(function () {
        var saml_lang = new SamlLanguage();
        var all_done = true;
        if ((saml_lang.lang_status === null) || (saml_lang.lang_status === undefined)) {
            all_done = false;
        }
        else {
            var keys = Object.keys(saml_lang.lang_status);
            for (var i = 0; i < keys; i++) {
                var key = keys[i];
                if (saml_lang.lang_status[key] !== 'done') {
                    all_done = false;
                    break;
                }
            }
        }
        if (all_done === true) {
            clearInterval(intervalID);
            document.getElementById('downloaded_event').click();
        }
    }, 100);

}

function init_post() {
    var saml_push_methods = document.getElementById('saml_push_methods');
    var push_method = saml_push_methods.getAttribute("data");
    if ((push_method === 'fido2') || (push_method === 'qrcode') || (push_method === 'multi') ) {
        page_switch('multi_login_page');
    }
    else {
        page_switch('select_account_page');
    }

    if ((localStorage === null) || (localStorage === undefined)) {
        console.log("LocalStorage not enable");
        return;
    }

    var account_list_json = localStorage.getItem("saml_account_list");
    if ((account_list_json !== null) && (account_list_json !== undefined)) {
        var account_list = JSON.parse(account_list_json);
        generate_account_list(account_list);
    }

    var edit_button_height = calc_select_account_page_edit_button_space_height();
    var space = document.getElementById('edit_account_menu_button_space');
    space.style.marginTop = edit_button_height + 'px';


    load_language();
    update_ui_lang();

    if (is_disable_captcha() === 'false') {
        reloadCaptcha();
    }
    else {
        var element = document.getElementById('captchaText');
        element.style = 'display: none';
        element = document.getElementById('verify_input');
        element.style = 'display: none';
        element = document.querySelector('[for="verify-input"]');
        element.style = 'display: none';
    }
}

function find_parent_tag_name(element, tag_name) {
    var parent_element = element;
    for (var i = 0; i < 50; i++) {
        parent_element = parent_element.parentElement;
        if ((parent_element === null) || (parent_element === undefined)) {
            return null;
        }
        else if (parent_element.tagName === tag_name) {
            return parent_element;
        }
    }

    return null;
}

function remove_storage_account_item(name) {
    var account_list_json = localStorage.getItem("saml_account_list");
    if ((account_list_json !== null) && (account_list_json !== undefined)) {
        var account_list = JSON.parse(account_list_json);
        if (account_list[name]) {
            delete (account_list[name]);
        }
        var a = JSON.stringify(account_list);
        localStorage.setItem("saml_account_list", a);
    }
}

function save_storage_account_item(name, Domain) {
    var login_name = name + '@' + Domain;
    var account_list_json = localStorage.getItem("saml_account_list");
    if ((account_list_json !== null) && (account_list_json !== undefined)) {
        var account_list = JSON.parse(account_list_json);
        account_list[login_name] = name;
        var data = JSON.stringify(account_list);
        localStorage.setItem("saml_account_list", data);
    }
    else {
        var a = new Object();
        a[login_name] = name;
        localStorage.setItem("saml_account_list", JSON.stringify(a));
    }
}

function append_delete_account_list(login_name) {
    if ((localStorage === null) || (localStorage === undefined)) {
        console.log("LocalStorage not enable");
        return;
    }

    if ((login_name === null) || (login_name === undefined)) {
        return;
    }

    var delete_account_list = localStorage.getItem("saml_delete_account_list");
    if ((delete_account_list !== null) && (delete_account_list !== undefined)) {
        delete_account_list = delete_account_list + "," + login_name;
    }
    else {
        delete_account_list = login_name;
    }

    localStorage.setItem("saml_delete_account_list", delete_account_list);
}

function delete_account(element) {
    var login_name = element.getAttribute('data');

    var table_element = find_parent_tag_name(element, "DIV");
    table_element.parentNode.removeChild(table_element);

    append_delete_account_list(login_name);
}

function edit_account_menu_button(element) {
    var delete_account_list = localStorage.getItem("saml_delete_account_list");
    if ((delete_account_list !== null) && (delete_account_list !== undefined)) {
        localStorage.removeItem("saml_delete_account_list");
    }
    
    var account_list_json = localStorage.getItem("saml_account_list");
    if ((account_list_json !== null) && (account_list_json !== undefined)) {
        var account_list = JSON.parse(account_list_json);
        generate_edit_account_list(account_list);
    }

    page_switch('edit_account_menu_page');
}

function generate_edit_account_list(accounts) {
    if ((accounts === null) || (accounts === undefined)) {
        return;
    }

    var myNode = document.getElementById("edit_account_menu");
    while (myNode.firstChild) {
        myNode.removeChild(myNode.lastChild);
    }

    var keys = Object.keys(accounts);
    for (var i = 0; i < keys.length; i++) {
        var name = accounts[keys[i]];
        var login_name = keys[i];

        var div = document.createElement("div");

        div.setAttribute("class", "table-responsive");
        div.setAttribute("style", "height: 77px;width: 340px;overflow: hidden;border-bottom: 1px outset #D1D1D1;");
        var table = document.createElement("table");
        table.setAttribute("class", "table");
        div.appendChild(table);

        var tbody = document.createElement("tbody");
        table.appendChild(tbody);
        var tr;
        var td;
        var span_login_name;
        var span_name;
        tr = document.createElement("tr");
        tr.setAttribute("style", "width: 300px;");
        tbody.appendChild(tr);

        td = document.createElement("td");
        td.setAttribute("style", "border-style: none;");
        tr.appendChild(td);
        span_name = document.createElement("span");
        span_name.setAttribute("style", "color: #202224;font-size: 17px;font-family: 'Poppins';");
        span_name.textContent = name;
        td.appendChild(span_name);

        td = document.createElement("td");
        td.setAttribute("style", "width: 60px;padding-top: 20px;");
        td.setAttribute("rowspan", "2");
        tr.appendChild(td);

        var button = document.createElement("button");
        button.setAttribute("class", "btn btn-primary");
        button.setAttribute("type", "button");
        button.setAttribute("style", "width: 38px;height: 38px;background: #F2F2F2;border-radius: 100px;border-width: 0px;border-style: none;padding: 0px;");
        button.setAttribute("data", login_name);
        button.setAttribute("onclick", "delete_account(this);");
        td.appendChild(button);
        var img = document.createElement("img");
        img.setAttribute("src", "/images/garbage_can_icon.png");
        img.setAttribute("style", "width: 25px;height: 25px;");
        button.appendChild(img);

        tr = document.createElement("tr");
        tr.setAttribute("style", "width: 300px;");
        tbody.appendChild(tr);

        td = document.createElement("td");
        span_name = document.createElement("span");
        span_name.setAttribute("style", "color: #959595;font-size: 15px;font-family: 'Poppins';");
        span_name.textContent = login_name;
        td.appendChild(span_name);
        tr.appendChild(td);

        document.getElementById("edit_account_menu").appendChild(div);

    }
}

function account_menus_on_click(element) {
    var div_ele = find_parent_tag_name(element, "DIV");
    var items = div_ele.querySelectorAll('.btn-account-menu')
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        if (element === item) {
            class_list_add(item, 'active');
			
			var data = element.getAttribute('data');
			do_account_menu_action(data);
        }
        else {
            class_list_remove(item, 'active');
        }
    }
}

function edit_account_list_complete_button_on_click(element) {
    if ((localStorage === null) || (localStorage === undefined)) {
        console.log("LocalStorage not enable");
        return;
    }

    var delete_account_list = localStorage.getItem("saml_delete_account_list");
    if ((delete_account_list !== null) && (delete_account_list !== undefined)) {
        var login_names = delete_account_list.split(',');
        for (var i = (login_names.length - 1); i >= 0; i--) {
            var login_name = login_names[i];
            remove_storage_account_item(login_name);
        }

        localStorage.removeItem("saml_delete_account_list");
    }

    var account_list_json = localStorage.getItem("saml_account_list");
    if ((account_list_json !== null) && (account_list_json !== undefined)) {
        var account_list = JSON.parse(account_list_json);
        generate_account_list(account_list);
    }

    page_switch('select_account_page');

    var edit_button_height = calc_select_account_page_edit_button_space_height();
    var space = document.getElementById('edit_account_menu_button_space');
    space.style.marginTop = edit_button_height + 'px';
}

function update_fido2_login_invalid_display(status) {
    var items = ["fido2-user-input"];
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        var input = document.getElementById(item);
        var input_label = input.nextSibling;

        if (status === 'error') {
            if ((item === 'fido2-user-input') || (item === 'paswd-input')) {
                class_list_remove(input, 'input-login');
                class_list_add(input, 'input-login-invalid');
                class_list_add(input_label, 'form-label-login-invalid');
                input.value = '';
            }
            else {
                class_list_remove(input, 'input-login-invalid');
                class_list_remove(input_label, 'form-label-login-invalid');
                class_list_add(input, 'input-login');
                input.value = '';
            }
        }
        else {
            class_list_remove(input, 'input-login-invalid');
            class_list_remove(input_label, 'form-label-login-invalid');
            class_list_add(input, 'input-login');
        }
    }
}

function update_login_invalid_display(status) {
    var items = ["user-input", "paswd-input", "verify_input"];
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        var input = document.getElementById(item);
        var input_label = input.nextSibling;

        if (status === 'verify_error') {
            if (item === 'verify_input') {
                class_list_remove(input, 'input-login');
                class_list_add(input, 'input-login-invalid');
                class_list_add(input_label, 'form-label-login-invalid');
                input.value = '';
            }
            else {
                class_list_remove(input, 'input-login-invalid');
                class_list_remove(input_label, 'form-label-login-invalid');
                class_list_add(input, 'input-login');
            }
        }
        else if (status === 'error') {
            if ((item === 'user-input') || (item === 'paswd-input')) {
                class_list_remove(input, 'input-login');
                class_list_add(input, 'input-login-invalid');
                class_list_add(input_label, 'form-label-login-invalid');
                input.value = '';
            }
            else {
                class_list_remove(input, 'input-login-invalid');
                class_list_remove(input_label, 'form-label-login-invalid');
                class_list_add(input, 'input-login');
                input.value = '';
            }
        }
        else {
            class_list_remove(input, 'input-login-invalid');
            class_list_remove(input_label, 'form-label-login-invalid');
            class_list_add(input, 'input-login');
        }
    }
}

function sha256(str) {
    return CryptoJS.SHA256(str).toString(CryptoJS.enc.Hex);
}

function padding_rsa_encrypted(encrypted) {
    let len = encrypted.length;
    if (len === 256)
        return encrypted;

    let padding_len = 256 - len;
    if (padding_len < 0)
        return encrypted;

    if (padding_len > 0) {
        let padding_str = '';
        let i = 0;
        for (i = 0; i < padding_len; i++) {
            padding_str += '\0';
        }

        let ret = padding_str + encrypted;
        return ret;
    }
}

function ui_countdown_timer(page, countdown_label, secs, next_page_name, redirect_url, trigger_event, success_token) {
    var ui_countdown_timer_id = null;
    var ui_countdown_timer_secs = 0;
    ui_countdown_timer_secs = secs;

    var saml_language = new SamlLanguage();
    var select_lang = saml_language.select_lang;
    var language = saml_language.languages[select_lang];

    countdown_label.textContent = ui_countdown_timer_secs.toString() + language['count-down-num-secs'];

    ui_countdown_timer_id = setInterval(function () {
        ui_countdown_timer_secs -= 1;

        var saml_language = new SamlLanguage();
        var select_lang = saml_language.select_lang;
        var language = saml_language.languages[select_lang];

        if (ui_countdown_timer_secs > 1) {
            countdown_label.textContent = ui_countdown_timer_secs.toString() + language['count-down-num-secs'];
        }
        else
            countdown_label.textContent = ui_countdown_timer_secs.toString() + language['count-down-num-sec'];

        if (ui_countdown_timer_secs < 0) {
            clearInterval(ui_countdown_timer_id);

            ui_countdown_timer_secs = 0;
            countdown_label.textContent = ui_countdown_timer_secs.toString() + language['count-down-num-sec'];

            if ((next_page_name != null) && (next_page_name != undefined)) {
                page_switch(next_page_name);
            }

            if ((next_page_name == null) && (redirect_url != null) && (redirect_url != undefined)) {
                location.href = redirect_url;
            }

            if ((next_page_name == null) && (redirect_url == null) && (trigger_event != null) && (trigger_event != undefined)) {
                eventBus.emit(trigger_event, null, page);
            }
        }
    }, 1000);

    return ui_countdown_timer_id;
}

function update_success_message(title, message) {
    var page = document.getElementById('result_success_page');
    var title_label = page.querySelector('.result_title_label');
    var message_label = page.querySelector('.result_message_label');
    title_label.textContent = title;
    message_label.textContent = message;
}

function show_vpn_info() {
    if (isIE() === true) {
        return;
    }
    var modal = document.getElementById('securitySpecModal');
    if (vpnModal === null)
        vpnModal = new bootstrap.Modal(modal);
    vpnModal.show();
}

function hide_vpn_info() {
    if (isIE() === true) {
        return;
    }
    if (vpnModal !== null)
        vpnModal.hide();
}

function calc_select_account_page_edit_button_space_height() {
    var edit_button_top = 330;	//根據編輯頁面, 選項高度 300, 間隔30 = 330
    var login_another_button = document.getElementById('login_another_button');
    var login_another_button_height = login_another_button.clientHeight;
    var account_menu = document.getElementById('account_menu');
    var account_menu_height = account_menu.clientHeight;
    return edit_button_top - login_another_button_height - account_menu_height - 20;
}

function lang_on_change(element) {
    var select_index = element.selectedIndex;
    var select_value = element.value;

    var lang_comboboxs = document.querySelectorAll('.select-lang-combobox');
    for (var i = 0; i < lang_comboboxs.length; i++) {
        var combobox = lang_comboboxs[i];
        if (combobox !== element) {
            combobox.selectedIndex = select_index;
        }
    }

    var saml_language = new SamlLanguage();
    saml_language.select_lang = select_value;

    localStorage.setItem("keypasco_saml_lang", select_value);
    update_ui_lang();
}

var SamlLanguage = (function () {
    var instance;

    return function () {
        if (typeof instance === 'object') return instance;
        this.p = 'public'
        instance = this;
        languages = new Object();
    }
}())
