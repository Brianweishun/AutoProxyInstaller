// jquery.jsonp 2.4.0 (c)2012 Julian Aubourg | MIT License
// https://github.com/jaubourg/jquery-jsonp
(function (e) { function t() { } function n(e) { C = [e] } function r(e, t, n) { return e && e.apply && e.apply(t.context || t, n) } function i(e) { return /\?/.test(e) ? "&" : "?" } function O(c) { function Y(e) { z++ || (W(), j && (T[I] = { s: [e] }), D && (e = D.apply(c, [e])), r(O, c, [e, b, c]), r(_, c, [c, b])) } function Z(e) { z++ || (W(), j && e != w && (T[I] = e), r(M, c, [c, e]), r(_, c, [c, e])) } c = e.extend({}, k, c); var O = c.success, M = c.error, _ = c.complete, D = c.dataFilter, P = c.callbackParameter, H = c.callback, B = c.cache, j = c.pageCache, F = c.charset, I = c.url, q = c.data, R = c.timeout, U, z = 0, W = t, X, V, J, K, Q, G; return S && S(function (e) { e.done(O).fail(M), O = e.resolve, M = e.reject }).promise(c), c.abort = function () { !(z++) && W() }, r(c.beforeSend, c, [c]) === !1 || z ? c : (I = I || u, q = q ? typeof q == "string" ? q : e.param(q, c.traditional) : u, I += q ? i(I) + q : u, P && (I += i(I) + encodeURIComponent(P) + "=?"), !B && !j && (I += i(I) + "_" + (new Date).getTime() + "="), I = I.replace(/=\?(&|$)/, "=" + H + "$1"), j && (U = T[I]) ? U.s ? Y(U.s[0]) : Z(U) : (E[H] = n, K = e(y)[0], K.id = l + N++, F && (K[o] = F), L && L.version() < 11.6 ? (Q = e(y)[0]).text = "document.getElementById('" + K.id + "')." + p + "()" : K[s] = s, A && (K.htmlFor = K.id, K.event = h), K[d] = K[p] = K[v] = function (e) { if (!K[m] || !/i/.test(K[m])) { try { K[h] && K[h]() } catch (t) { } e = C, C = 0, e ? Y(e[0]) : Z(a) } }, K.src = I, W = function (e) { G && clearTimeout(G), K[v] = K[d] = K[p] = null, x[g](K), Q && x[g](Q) }, x[f](K, J = x.firstChild), Q && x[f](Q, J), G = R > 0 && setTimeout(function () { Z(w) }, R)), c) } var s = "async", o = "charset", u = "", a = "error", f = "insertBefore", l = "_jqjsp", c = "on", h = c + "click", p = c + a, d = c + "load", v = c + "readystatechange", m = "readyState", g = "removeChild", y = "<script>", b = "success", w = "timeout", E = window, S = e.Deferred, x = e("head")[0] || document.documentElement, T = {}, N = 0, C, k = { callback: l, url: location.href }, L = E.opera, A = !!e("<div>").html("<!--[if IE]><i><![endif]-->").find("i").length; O.setup = function (t) { e.extend(k, t) }, e.jsonp = O })(jQuery)

/**
*
*  Base64 encode / decode
*  http://www.webtoolkit.info/
*
**/
var Base64={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",encode:function(c){var a="";var k,h,f,j,g,e,d;var b=0;c=Base64._utf8_encode(c);while(b<c.length){k=c.charCodeAt(b++);h=c.charCodeAt(b++);f=c.charCodeAt(b++);j=k>>2;g=((k&3)<<4)|(h>>4);e=((h&15)<<2)|(f>>6);d=f&63;if(isNaN(h)){e=d=64}else{if(isNaN(f)){d=64}}a=a+this._keyStr.charAt(j)+this._keyStr.charAt(g)+this._keyStr.charAt(e)+this._keyStr.charAt(d)}return a},decode:function(c){var a="";var k,h,f;var j,g,e,d;var b=0;c=c.replace(/[^A-Za-z0-9\+\/\=]/g,"");while(b<c.length){j=this._keyStr.indexOf(c.charAt(b++));g=this._keyStr.indexOf(c.charAt(b++));e=this._keyStr.indexOf(c.charAt(b++));d=this._keyStr.indexOf(c.charAt(b++));k=(j<<2)|(g>>4);h=((g&15)<<4)|(e>>2);f=((e&3)<<6)|d;a=a+String.fromCharCode(k);if(e!=64){a=a+String.fromCharCode(h)}if(d!=64){a=a+String.fromCharCode(f)}}a=Base64._utf8_decode(a);return a},_utf8_encode:function(b){b=b.replace(/\r\n/g,"\n");var a="";for(var e=0;e<b.length;e++){var d=b.charCodeAt(e);if(d<128){a+=String.fromCharCode(d)}else{if((d>127)&&(d<2048)){a+=String.fromCharCode((d>>6)|192);a+=String.fromCharCode((d&63)|128)}else{a+=String.fromCharCode((d>>12)|224);a+=String.fromCharCode(((d>>6)&63)|128);a+=String.fromCharCode((d&63)|128)}}}return a},_utf8_decode:function(a){var b="";var d=0;var e=c1=c2=0;while(d<a.length){e=a.charCodeAt(d);if(e<128){b+=String.fromCharCode(e);d++}else{if((e>191)&&(e<224)){c2=a.charCodeAt(d+1);b+=String.fromCharCode(((e&31)<<6)|(c2&63));d+=2}else{c2=a.charCodeAt(d+1);c3=a.charCodeAt(d+2);b+=String.fromCharCode(((e&15)<<12)|((c2&63)<<6)|(c3&63));d+=3}}}return b}};

/*
 * Customer vakten javascript (JSONP version) 0.7.0 (2018-04-06)
 * Copyright (c) 2018 Keypasco AB
 */

var ports = ["14057", "16057", "17057"];

function internal_launch_vakten(resource, applicationName)
{
    var vaktenProtocolName = typeof applicationName !== 'undefined' ? applicationName : "vakten";
    var url = vaktenProtocolName + ":" + Base64.encode(resource);
    var vaktenLinkName = "vaktenLink";
    var existingLink = document.getElementById(vaktenLinkName)
    if(existingLink) {
        existingLink.parentNode.removeChild(existingLink);
    }

    var anchor = document.createElement('a');
    anchor.href =  url;
    anchor.innerHTML = "Hidden Link";
    anchor.setAttribute("id", vaktenLinkName);
    anchor.setAttribute("style", "display:none;");
    anchor.setAttribute("target", "");
    document.body.appendChild(anchor);

    var createdLink = document.getElementById(vaktenLinkName)
    if(createdLink === null || createdLink == undefined)
    {
        return 500;
    }

    if(createdLink.dispatchEvent)
    {
        var event = document.createEvent("MouseEvents");
        event.initEvent("click", true, true);
        event.foo = url;
        createdLink.dispatchEvent(event);
    }
    else if(createdLink.click)
    {
        createdLink.click();
    }
    else
    {
        return 500;
    }
    return 199;
}

function status_i(portIndex, callback_result, applicationName) {
    "use strict";

    var resource = "/api/2/status.jsonp?callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode !== null && data.statusCode.length !== 0) {
                callback_result(data.statusCode);
            } else {
                callback_result(500); // failure
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName));
            } else {
                status_i(portIndex, callback_result, vaktenUrl, applicationName);
            }
        }
    });
}

/** @desc The Keypasco Vakten register method
  * @param $callback_result - function that will receive the result message
  * @param applicationName  - the name of the application as provided by keypasco */
function vaktenStatus(callback_result, applicationName) {
    "use strict";
    status_i(0, callback_result, applicationName);
}


function internal_associate(attempt, port, icpId, sessionId, callback_result, vaktenUrl, applicationName) {
    "use strict";

    var resource = "/api/2/associate.jsonp?customerId=" + icpId + "&sessionId=" + sessionId  + "&api=" + vaktenUrl + "&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + port + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    internal_associate(attempt, port, customerId, sessionId, callback_result, vaktenUrl, applicationName);
                } else {
                    callback_result(500); // failure
                }
            } else {
                callback_result(data.statusCode);
            }
        },
        "error": function (d, msg) {
            callback_result(internal_launch_vakten(resource, applicationName));
        }
    });
}

function internal_status_chain(portIndex, icpId, sessionId, callback_result, callback_started, vaktenUrl, applicationName) {
    "use strict";

    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + "/api/2/status.jsonp?&callback=?",
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode !== null && data.statusCode.length !== 0) {
                callback_started();
                if (data.statusCode === 200) {
                    internal_associate(0, ports[portIndex], icpId, sessionId, callback_result, vaktenUrl, applicationName);
                } else {
                    callback_result(400); // failure
                }
            } else {
                callback_result(500); // failure
            }
        },
        "error": function (d, msg) {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_started();
                internal_associate(0, ports[0], icpId, sessionId, callback_result, vaktenUrl, applicationName);
            } else {
                internal_status_chain(portIndex, icpId, sessionId, callback_result, callback_started, vaktenUrl, applicationName);
            }
        }
    });
}

/** @desc The Keypasco Vakten register function
  * @param icpId             - the customers special id
  * @param sessionId         - used to coordinate communication
  * @param callback_result   - function that will receive the result message
  * @param callback_started  - function that will receive a call when the process starts
  * @param vaktenUrl         - a URL that Vakten will target 
  * @param applicationName   - the name of the application as provided by keypasco */
function vaktenRegister(icpId, sessionId, callback_result, callback_started, vaktenUrl, applicationName) {
    "use strict";
    internal_status_chain(0, icpId, sessionId, callback_result, callback_started, vaktenUrl, applicationName);
}


function authenticate_i(portIndex, attempt, icpId, sessionId, callback_result, vaktenUrl, applicationName) {
    "use strict";

	var resource = "/api/2/authenticate.jsonp?customerId=" + icpId + "&sessionId=" + sessionId + "&api=" + vaktenUrl + "&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    authenticate_i(portIndex, attempt, icpId, sessionId, callback_result, vaktenUrl);
                } else {
                    callback_result(500); // failure
                }
            } else {
                callback_result(data.statusCode);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName));
            } else {
                authenticate_i(portIndex, attempt, icpId, sessionId, callback_result, vaktenUrl, applicationName);
            }
        }
    });
}

/** @desc The Keypasco Vakten authentication method
  * @param icpId            - the customers special id
  * @param sessionId        - used to coordinate communication
  * @param callback_result  - function that will receive the result message
  * @param vaktenUrl        - a URL that Vakten will target
  * @param applicationName  - the name of the application as provided by keypasco */
function vaktenAuthenticate(icpId, sessionId, callback_result, vaktenUrl, applicationName) {
    "use strict";
    authenticate_i(0, 0, icpId, sessionId, callback_result, vaktenUrl, applicationName);
}

function signTask_i(portIndex, attempt, taskId, callback_result, vaktenUrl, applicationName) {
    "use strict";

	var resource = "/api/2/task.jsonp?taskId=" + taskId + "&api=" + vaktenUrl + "&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    signTask_i(portIndex, attempt, taskId, callback_result, vaktenUrl, applicationName);
                } else {
                    callback_result(500); // failure
                }
            } else {
                callback_result(data.statusCode);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName));
            } else {
                signTask_i(portIndex, attempt, taskId, callback_result, vaktenUrl, applicationName);
            }
        }
    });
}

function vaktenSignTask(taskId, callback_result, vaktenUrl, applicationName) {
	signTask_i(0, 0, taskId, callback_result, vaktenUrl, applicationName);
}

function vaktenActivateProximity_i(portIndex, attempt, icpId, purchaseId, signature, callback_result, vaktenUrl, applicationName) {
    "use strict";
    var resource = "/api/2/activateProximity.jsonp?customerId=" + icpId + "&purchaseId=" + purchaseId + "&api=" + vaktenUrl + "&signature=" + signature + "&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    vaktenActivateProximity_i(portIndex, attempt, icpId, purchaseId, signature, callback_result, vaktenUrl, applicationName);
                } else {
                    callback_result(500, ''); // failure
                }
            } else {
                callback_result(data.statusCode, data.PUC);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName), '');
            } else {
                vaktenActivateProximity_i(portIndex, attempt, icpId, purchaseId, signature, callback_result, vaktenUrl, applicationName);
            }
        }
    });
}

/** @desc The Keypasco Vakten addProximity method
  * @param icpId           - the customers special id
  * @param purchaseId      - used to coordinate communication
  * @param signature       - signature of the purchaseId
  * @param callback_result - function that will receive the result message
  * @param vaktenUrl       - a URL that Vakten will target
  * @param applicationName - the name of the application as provided by keypasco */
function vaktenActivateProximity(icpId, purchaseId, signature, callback_result, vaktenUrl, applicationName) {
    "use strict";
    vaktenActivateProximity_i(0, 0, icpId, purchaseId, signature, callback_result, vaktenUrl, applicationName);
}

function vaktenGetUuid_i(portIndex, attempt, callback_result) {
    "use strict";
    var resource = "/api/2/uuid.jsonp?&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    vaktenGetUuid_i(portIndex, attempt, callback_result);
                } else {
                    callback_result(500, ''); // failure
                }
            } else {
                callback_result(data.statusCode, data.uuid);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName), '');
            } else {
                vaktenGetUuid_i(portIndex, attempt, callback_result);
            }
        }
    });
}

/** @desc The Keypasco Vakten getUuid method
  * @param callback_result - function that will receive the result message */
function vaktenGetUuid(callback_result) {
    "use strict";
    vaktenGetUuid_i(0, 0, callback_result);
}

function vaktenGetUuid_i_v2(portIndex, attempt, callback_result) {
    "use strict";
    var resource = "/api/2/uuidV2.jsonp?&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    vaktenGetUuid_i_v2(portIndex, attempt, callback_result);
                } else {
                    callback_result(500, ''); // failure
                }
            } else {
                callback_result(data.statusCode, data.uuid);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName), '');
            } else {
                vaktenGetUuid_i_v2(portIndex, attempt, callback_result);
            }
        }
    });
}

/** @desc The Keypasco Vakten getUuid method
  * @param callback_result - function that will receive the result message */
function vaktenGetUuid_v2(callback_result) {
    "use strict";
    vaktenGetUuid_i_v2(0, 0, callback_result);
}
function vaktenGetTpmVersion_i(portIndex, attempt, callback_result) {
    "use strict";
    var resource = "/api/2/getTpmVersion.jsonp?&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    vaktenGetTpmVersion_i(portIndex, attempt, callback_result);
                } else {
                    callback_result(500, ''); // failure
                }
            } else {
                callback_result(data.statusCode, data.tpmVersion);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName), '');
            } else {
                vaktenGetTpmVersion_i(portIndex, attempt, callback_result);
            }
        }
    });
}

/** @desc The Keypasco Vakten get TPM version method
 * @param callback_result - function that will receive the result message */
function vaktenGetTpmVersion(callback_result) {
    "use strict";
    vaktenGetTpmVersion_i(0, 0, callback_result);
}

function vaktenGetPublicKey_i(portIndex, attempt, icpId, userId, callback_result) {
    "use strict";
    var resource = "/api/2/getPublicKey.jsonp?customerId=" + icpId + "&user_id=" + userId + "&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    vaktenGetPublicKey_i(portIndex, attempt, icpId, userId, callback_result);
                } else {
                    callback_result(500, '', ''); // failure
                }
            } else {
                callback_result(data.statusCode, data.publicSignKey, data.publicEncryptKey);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName), '');
            } else {
                vaktenGetPublicKey_i(portIndex, attempt, icpId, userId, callback_result);
            }
        }
    });
}

/** @desc The Keypasco Vakten get public key method
 * @param icpId - customer id
 * @param userId - user id
 * @param callback_result - function that will receive the result message */
function vaktenGetPublicKey(icpId, userId, callback_result) {
    "use strict";
    vaktenGetPublicKey_i(0, 0, icpId, userId, callback_result);
}

function vaktenGetPublicKey_2_i(portIndex, attempt, icpId, userId, tpmversion, callback_result) {
    "use strict";
    var resource = "/api/2/getPublicKey_2.jsonp?customerId=" + icpId + "&user_id=" + userId + "&tpmversion=" + tpmversion + "&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    vaktenGetPublicKey_2_i(portIndex, attempt, icpId, userId, tpmversion, callback_result);
                } else {
                    callback_result(500, '', ''); // failure
                }
            } else {
                callback_result(data.statusCode, data.publicSignKey, data.publicEncryptKey);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName), '');
            } else {
                vaktenGetPublicKey_2_i(portIndex, attempt, icpId, userId, tpmversion, callback_result);
            }
        }
    });
}

/** @desc The Keypasco Vakten get public key method
 * @param icpId - customer id
 * @param userId - user id
 * @param callback_result - function that will receive the result message */
function vaktenGetPublicKey_2(icpId, userId, tpmversion, callback_result) {
    "use strict";
    vaktenGetPublicKey_2_i(0, 0, icpId, userId, tpmversion, callback_result);
}

function vaktenVerifyPublicKey_i(portIndex, attempt, publicKey, tpmversion, callback_result) {
    "use strict";
    var resource = "/api/2/verifyPublicKey.jsonp?public_key=" + publicKey + "&tpm_version=" + tpmversion + "&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    vaktenVerifyPublicKey_i(portIndex, attempt, publicKey, tpmversion, callback_result);
                } else {
                    callback_result(500); // failure
                }
            } else {
                callback_result(data.statusCode);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName), '');
            } else {
                vaktenVerifyPublicKey_i(portIndex, attempt, publicKey, tpmversion, callback_result);
            }
        }
    });
}

/** @desc The Keypasco Vakten get public key method
 * @param callback_result - function that will receive the result message */
function vaktenVerifyPublicKey(publicKey, tpmversion, callback_result) {
    "use strict";
    vaktenVerifyPublicKey_i(0, 0, publicKey, tpmversion, callback_result);
}

function vaktenVerifyPublicKey_2_i(portIndex, attempt, publicKey, tpmversion, callback_result) {
    "use strict";
    var resource = "/api/2/verifyPublicKey_2.jsonp?public_key=" + publicKey + "&tpm_version=" + tpmversion + "&callback=?";
    //var resource = "/api/2/verifyPublicKey.jsonp?public_key=" + publicKey + "&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    vaktenVerifyPublicKey_2_i(portIndex, attempt, publicKey, tpmversion, callback_result);
                } else {
                    callback_result(500); // failure
                }
            } else {
                callback_result(data.statusCode);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName), '');
            } else {
                vaktenVerifyPublicKey_2_i(portIndex, attempt, publicKey, tpmversion, callback_result);
            }
        }
    });
}

/** @desc The Keypasco Vakten get public key method
 * @param callback_result - function that will receive the result message */
function vaktenVerifyPublicKey_2(publicKey, tpmversion, callback_result) {
    "use strict";
    vaktenVerifyPublicKey_2_i(0, 0, publicKey, tpmversion, callback_result);
}

function vaktenGetComputerType_i(portIndex, attempt, callback_result) {
    "use strict";
    var resource = "/api/2/getComputerType.jsonp?&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    vaktenGetComputerType_i(portIndex, attempt, callback_result);
                } else {
                    callback_result(500, ''); // failure
                }
            } else {
                callback_result(data.statusCode, data.computerType);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName), '');
            } else {
                vaktenGetComputerType_i(portIndex, attempt, callback_result);
            }
        }
    });
}

/** @desc The Keypasco Vakten getUuid method
  * @param callback_result - function that will receive the result message */
function vaktenGetComputerType(callback_result) {
    "use strict";
    vaktenGetComputerType_i(0, 0, callback_result);
}

function vaktenGetSignedMessage_i(portIndex, attempt, icpId, userId, publicKey, callback_result) {
    "use strict";
    var resource = "/api/2/getSignedMessage.jsonp?customerId=" + icpId + "&user_id=" + userId + "&public_key=" + publicKey + "&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    vaktenGetSignedMessage_i(portIndex, attempt, icpId, userId, publicKey, callback_result);
                } else {
                    callback_result(500, '', ''); // failure
                }
            } else {
                callback_result(data.statusCode, data.hashMessage, data.signature);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName), '');
            } else {
                vaktenGetSignedMessage_i(portIndex, attempt, icpId, userId, publicKey, callback_result);
            }
        }
    });
}

/** @desc The Keypasco Vakten get public key method
 * @param icpId - customer id
 * @param userId - user id
 * @param publicKey - public key
 * @param callback_result - function that will receive the result message */
function vaktenGetSignedMessage(icpId, userId, publicKey, callback_result) {
    "use strict";
    vaktenGetSignedMessage_i(0, 0, icpId, userId, publicKey, callback_result);
}

function vaktenDecryptMessage_i(portIndex, attempt, icpId, userId, encryptMessage, callback_result) {
    "use strict";
    var resource = "/api/2/decryptMessage.jsonp?customerId=" + icpId + "&user_id=" + userId + "&encrypt_message=" + encryptMessage + "&callback=?";
    $.jsonp({
        "url": "https://vaktenlocal.com:" + ports[portIndex] + resource,
        "data": {
            "alt": "json-in-script"
        },
        "success": function (data) {
            if (data.statusCode === 597 || data.statusCode === 598 || data.statusCode === 599) {
                attempt = attempt + 1;
                if (attempt < 10) {
                    vaktenDecryptMessage_i(portIndex, attempt, icpId, userId, encryptMessage, callback_result);
                } else {
                    callback_result(500, ''); // failure
                }
            } else {
                callback_result(data.statusCode, data.decryptMessage);
            }
        },
        "error": function () {
            portIndex = portIndex + 1;
            if (portIndex === ports.length) {
                callback_result(internal_launch_vakten(resource, applicationName), '');
            } else {
                vaktenDecryptMessage_i(portIndex, attempt, icpId, userId, encryptMessage, callback_result);
            }
        }
    });
}

/** @desc The Keypasco Vakten get public key method
 * @param icpId - customer id
 * @param userId - user id
 * @param encryptMessage - encrypt message
 * @param callback_result - function that will receive the result message */
function vaktenDecryptMessage(icpId, userId, encryptMessage, callback_result) {
    "use strict";
    vaktenDecryptMessage_i(0, 0, icpId, userId, encryptMessage, callback_result);
}