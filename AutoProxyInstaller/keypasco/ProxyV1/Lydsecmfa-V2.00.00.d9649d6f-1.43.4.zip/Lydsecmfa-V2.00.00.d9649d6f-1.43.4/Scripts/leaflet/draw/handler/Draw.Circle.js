L.Draw.Circle = L.Draw.SimpleShape.extend({
    statics: {
        TYPE: 'circle'
    },

    options: {
        shapeOptions: {
            stroke: true,
            color: '#3388ff',
            weight: 4,
            opacity: 0.5,
            fill: true,
            fillColor: null,
            fillOpacity: 0.2,
            clickable: true
        },
        showRadius: true,
        metric: true,
        feet: true,
        nautic: false
    },

    initialize: function (map, options) {
        this.type = L.Draw.Circle.TYPE;

        this._initialLabelText = L.drawLocal.draw.handlers.circle.tooltip.start;

        L.Draw.SimpleShape.prototype.initialize.call(this, map, options);
    },

    _drawShape: function (latlng) {
        if (L.GeometryUtil.isVersion07x()) {
            var distance = this._startLatLng.distanceTo(latlng);
        } else {
            var distance = this._map.distance(this._startLatLng, latlng);
        }

        if (!this._shape) {
            this._shape = new L.Circle(this._startLatLng, distance, this.options.shapeOptions);
            this._map.addLayer(this._shape);
        } else {
            this._shape.setRadius(distance);
        }
    },

    _fireCreatedEvent: function () {
        var circle = new L.Circle(this._startLatLng, this._shape.getRadius(), this.options.shapeOptions);

        // TODO: Get Lat and Lng through this._startLatLng (John)

        L.Draw.SimpleShape.prototype._fireCreatedEvent.call(this, circle);
    },

    _onMouseMove: function (e) {
        var latlng = e.latlng,
            showRadius = this.options.showRadius,
            useMetric = this.options.metric,
            radius;

        this._tooltip.updatePosition(latlng);
        if (this._isDrawing) {
            this._drawShape(latlng);

            radius = Math.round(this._shape.getRadius());

            // TODO: Refactor this
            let circleData = this._startLatLng + ',' + radius;
            circleData = circleData.replace('LatLng(', '').replace(')', '').replace(' ', '');            sessionStorage.setItem('circleData', circleData);

            var subtext = '';
            if (showRadius) {
                subtext = L.drawLocal.draw.handlers.circle.radius + ': ' +
                    L.GeometryUtil.readableDistance(radius, useMetric, this.options.feet, this.options.nautic);
            }
            this._tooltip.updateContent({
                text: this._endLabelText,
                subtext: subtext
            });
        }
    }
});