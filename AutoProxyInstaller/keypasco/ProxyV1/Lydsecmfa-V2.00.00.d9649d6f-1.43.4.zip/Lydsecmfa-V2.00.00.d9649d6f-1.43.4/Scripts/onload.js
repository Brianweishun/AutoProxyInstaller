﻿var user_info = null;
var logo_list = [];

const GotUserInfoEvent = new CustomEvent('GotUserInfoEvent', {
    UserInfo: null
});

const GotAppListEvent = new CustomEvent('GotAppListEvent', {
    AppList: null
});

const GotAllLogosEvent = new CustomEvent('GotAllLogosEvent', {
    AppList: null,
    LogoFileIdMap: null
});

function processing_got_user_info(event) {
    console.log(event);

    var url = '/WebApp/ListApp';
    var auth_bearer = 'Bearer ' + user_info['na_token'];
    fetch(url, {
        method: "GET",
        headers: {
            "Authorization": auth_bearer
        }
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }

            return response.text();
        })
        .then(value => {
            console.log(value);
            const dataArray = JSON.parse(value);

            GotAppListEvent.AppList = dataArray;
            processing_got_app_list(GotAppListEvent);
            //window.dispatchEvent(GotAppListEvent);
        })
        .catch(function (error) {
            console.log(error);
        });
}

function processing_got_app_list(event) {
    console.log(event);
    var dataArray = event.AppList;
    console.log('資料陣列:', dataArray);
    console.log('資料筆數:', dataArray.length);

    const logo_fetches = [];
    var LogoFileIdMap = new Map();

    for (var i = 0; i < dataArray.length; i++) {
        (function (data) {
            var data = dataArray[i];
            var file_id = data.LogoFileID;

            var url = "/FileStorage/DownloadLogoID?FileId=" + file_id;
            let logo_fetch = fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok ' + response.statusText);
                    }

                    return response.text();
                })
                .then(data => {
                    LogoFileIdMap.set(file_id, data);
                })
                .catch(error => {
                    // 處理錯誤
                    console.error('There was a problem with the fetch operation:', error);
                });
            logo_fetches.push(logo_fetch);
        })(dataArray[i]);
    }

    Promise.all(logo_fetches)
        .then(function () {
            GotAllLogosEvent.AppList = dataArray;
            GotAllLogosEvent.LogoFileIdMap = LogoFileIdMap;
            processing_got_all_logos(GotAllLogosEvent);
            //window.dispatchEvent(GotAllLogosEvent);

            let userinfo_panel = document.querySelector('.userinfo_panel');
            let user_id_element = userinfo_panel.querySelector('.userinfo_userid');
            let user_id = user_info['userid'];
            user_id_element.textContent = user_id;
            let first_letter = user_id.charAt(0).toUpperCase();
            let userinfo_label = document.querySelector('.UserInfoLabel');
            userinfo_label.textContent = first_letter;
        });
}

function processing_got_all_logos(event) {
    console.log(event);
    var dataArray = event.AppList;
    var LogoFileIdMap = event.LogoFileIdMap;
    createLinkButton(dataArray.length, dataArray, LogoFileIdMap);
    if (user_info.isadmin === true) {
        createAddButton();
    }
    close_loading_spinner();
}

window.onload = function () {
    open_loading_spinner();
    load_user_info();

    delay(5000, "")
        .then(function (value) {
            close_loading_spinner();
        });

    document.querySelector('.sidebar-close-button').addEventListener('click', function () {
        addflag = false;
        editflag = false;
        resetvalue();
        document.getElementById('sidebar').style.right = '-350px';
        document.getElementById('overlay').style.display = 'none';
    });

    document.querySelector('.sidebar-cancel-button').addEventListener('click', function () {
        addflag = false;
        editflag = false;
        resetvalue();
        document.getElementById('sidebar').style.right = '-350px';
        document.getElementById('overlay').style.display = 'none';
    });

    document.getElementById('overlay').addEventListener('click', function () {
        editflag = false;
        addflag = false;
        let selectedDiv = document.querySelector('.selected');
        if (selectedDiv) {
            selectedDiv.classList.remove('selected');
        }
        resetvalue();
        document.getElementById('sidebar').style.right = '-350px';
        document.getElementById('overlay').style.display = 'none';
    });
};

function open_token_error_messagebox(title, message, url) {
    var messagebox = document.querySelector(".TokenErrorMessageBox");
    var messagebox_title = document.querySelector(".TokenErrorMessageBoxTitle");
    var messagebox_message = document.querySelector(".TokenErrorMessageBoxMessage");
    var messagebox_button = document.querySelector(".TokenErrorMessageBoxButton");

    messagebox_title.textContent = title;
    messagebox_message.textContent = message;

    messagebox_button.href = url;
    var messagebox = document.querySelector(".TokenErrorMessageBox");
    var modal = bootstrap.Modal.getInstance(messagebox);
    if (modal === null)
        modal = new bootstrap.Modal(messagebox);
    modal.show();

    setTimeout(function () {
        location.href = url;
    }, 5000);
}

function load_user_info() {
    var na_token = localStorage.getItem('na_token');
    if ((na_token === null) || (na_token === undefined)) {
        close_loading_spinner();
        open_token_error_messagebox("Error", "Token過期", '/Saml/WebApp');
        return;
    }

    var url = "/WebApp/GetInfo";
    fetch(url, {
        method: "GET",
        headers: {
            'Authorization': 'Bearer ' + na_token,
        }
    })
        .then(function(response) {
            if (!response.ok) {
                open_info_messagebox("Error", "Server No Response");
            }

            return response.text();
        })
        .then(function(data) {
            data = data.replace('"True"', 'true')
                .replace('"False"', 'false')
                .replace('"true"', 'true')
                .replace('"false"', 'false')
                .replace("'True'", 'true')
                .replace("'False'", 'false')
                .replace("'true'", 'true')
                .replace("'false'", 'false');
            user_info = JSON.parse(data);
            if (user_info.result !== 'success') {
                close_loading_spinner();
                open_token_error_messagebox("Error", "Token過期", '/Saml/WebApp');
                return;
            }

            user_info['na_token'] = localStorage.getItem('na_token');

            GotUserInfoEvent.UserInfo = user_info;
            processing_got_user_info(GotUserInfoEvent);
            //window.dispatchEvent(GotUserInfoEvent);
        })
        .catch(function(error){
            // 處理錯誤
            console.error('There was a problem with the fetch operation:', error);
        });
}

function createLinkButton(length, object, LogoFileIdMap) {
    // 找到 #group 元素
    let groupElement = document.getElementById('group');

    // 創建新的 .rowlist 元素
    let newRowList = document.createElement('div');
    newRowList.className = 'rowlist';
    newRowList.classList.add('addlist-row');
    // 將新的 .rowlist 元素添加到 #group 中
    groupElement.appendChild(newRowList);

    // 在新的 .rowlist 元素中根據資料數量添加 .linkbutton 元素
    for (let i = 1; i <= length; i++) {
        // 1行5個
        if (i % 5 == 1 && i != 1) {
            let newRowList = document.createElement('div');
            newRowList.className = 'rowlist addlist-row';
            groupElement.appendChild(newRowList);
        }

        // 創建 .linkbutton 元素
        let linkButton = document.createElement('div');
        linkButton.className = 'linkbutton linkbox';

        let app_data_object = object[i - 1];
        linkButton.setAttribute('data-appid', app_data_object.Id);
        linkButton.setAttribute('data-appname', app_data_object.AppName);
        linkButton.setAttribute('data-type', app_data_object.Type);
        linkButton.setAttribute('data-account_id', app_data_object.AccountID);
        linkButton.setAttribute('data-logofileid', app_data_object.LogoFileID);
        linkButton.setAttribute('data-siteurl', app_data_object.SiteURL);
        linkButton.setAttribute('data-descript', app_data_object.Description);
        linkButton.setAttribute('data-userid', app_data_object.UserID);
        linkButton.setAttribute('data-created', app_data_object.Created);
        linkButton.setAttribute('data-redirect-url', app_data_object.SignOnRedirectURL);
        linkButton.setAttribute('data-subject', app_data_object.SignOnSubject);
        linkButton.setAttribute('data-expire-time', app_data_object.SignOnExpireTime);
        linkButton.setAttribute('onclick', 'app_herf_onclick(this)');

        let editButton = document.createElement('div');
        editButton.className = 'editbutton';
        editButton.setAttribute('onclick', 'app_edit_onclick(this,event)');
        if (user_info.isadmin === false) {
            editButton.style.display = 'none';
        }
        let label = document.createElement('label');
        label.className = 'form-label';
        label.innerText = '···';
        label.style.cursor = 'pointer';
        editButton.appendChild(label);

        let imageArea = document.createElement('div');
        imageArea.className = 'imagearea';

        let imageTextArea = document.createElement('div');
        imageTextArea.className = 'imagetextarea';
        let paragraph = document.createElement('p');
        paragraph.innerText = app_data_object.AppName;
        imageTextArea.appendChild(paragraph);

        linkButton.appendChild(editButton);
        linkButton.appendChild(imageArea);
        linkButton.appendChild(imageTextArea);

        let logo = document.createElement('img');
        let img_id = "logo-" + app_data_object.Id;
        logo.setAttribute("style", "width:85px; height: 85px;");
        logo.src = LogoFileIdMap.get(app_data_object.LogoFileID);
        logo.classList.add(img_id);
        imageArea.appendChild(logo);

        let rowLists = document.querySelectorAll('.rowlist');
        let lastRowList = rowLists[rowLists.length - 1];
        lastRowList.appendChild(linkButton);
    }

}
function createAddButton() {
    // 找所有的 .rowlist 元素
    let rowLists = document.querySelectorAll('.rowlist');

    // 找最後一個 .rowlist 元素
    let lastRowList = rowLists[rowLists.length - 1];

    // 如果最後一個 .rowlist 元素不存在或已滿 5 個內容 div，則創建新的 .rowlist 元素
    if (!lastRowList || lastRowList.children.length >= 5) {
        lastRowList = document.createElement('div');
        lastRowList.className = 'rowlist addlist-row';
        document.getElementById('group').appendChild(lastRowList);
    }

    // 創建 addbutton
    let addbutton = document.createElement('div');
    addbutton.id = 'add';
    addbutton.className = 'addlinkbutton';

    let addContent = document.createElement('h1');
    addContent.innerText = '+';
    addbutton.appendChild(addContent);

    // 將 addbutton 添加到最後一個 .rowlist 元素中
    lastRowList.appendChild(addbutton);
    AddClickEvent();

}

function app_herf_onclick(event) {
    console.log(event);
    let element = event;
    let account_id = element.getAttribute('data-account_id');
    let user = user_info['userid'];
    let user_id = element.getAttribute('data-userid');
    let type = element.getAttribute('data-type');
    let site = element.getAttribute('data-siteurl');
    let app_id = element.getAttribute('data-appid');
    let data = user + '#' + user_id + '#' + account_id + '#' + type + '#' + app_id  + '#' + site;
    data = rsa_encrypt(data);

    if ((type === "davinci") || (type === "site") || (type === "webapp") ) {
        var auth_bearer = 'Bearer ' + user_info['na_token'];
        let post_data = {
            "NaToken": localStorage.getItem('na_token'),
            "Data": data
        };
        fetch("/Saml/LoginApp",
            {
                headers: {
                    "Authorization": auth_bearer,
                    'Content-Type': 'application/json'
                },
                method: "POST",
                body: JSON.stringify(post_data)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                console.log(data);
                if (type === "webapp") {
                    if (data.status === 1) {
                        var form_div = document.createElement('div');
                        document.body.appendChild(form_div);

                        var form = document.createElement('form');
                        form.method = "post";
                        form.action = data.redirect_url;
                        form.id = "post_form";

                        var token_input = document.createElement('input');
                        token_input.type = 'hidden';
                        token_input.name = 'token';
                        token_input.value = data.token;
                        form.appendChild(token_input);

                        var status_input = document.createElement('status');
                        status_input.type = 'hidden';
                        status_input.name = 'status';
                        status_input.value = status.toString();

                        form.appendChild(status_input);

                        form_div.appendChild(form);
                        form.submit();

                        form_div.textContent = '';
                    }
                    else {
                        open_info_messagebox("Error", data.error);
                    }

                    return;
                }

                else if (data.result === 'success') {
                    location = data.url;
                }
                else {
                    open_info_messagebox("Error", data.error);
                }
            });
    }

    else {
        let form = null;
        form = document.querySelector('.netsuite_form');
        if ((form !== null) && (form !== undefined)) {
            document.body.removeChild(form);
        }

        form = document.createElement('form');
        form.setAttribute("class", "netsuite_form");
        form.setAttribute("method", "post");
        form.setAttribute("action", "/Saml/LoginWebApp");
        let na_token_element = document.createElement('input');
        na_token_element.setAttribute('type', 'hidden');
        na_token_element.setAttribute('name', 'na_token');
        na_token_element.setAttribute('value', localStorage.getItem('na_token'));
        form.appendChild(na_token_element);

        let user_id_element = document.createElement('input');
        user_id_element.setAttribute('type', 'hidden');
        user_id_element.setAttribute('name', 'data');
        user_id_element.setAttribute('value', data);
        form.appendChild(user_id_element);

        let submit = document.createElement('input');
        submit.setAttribute('type', 'submit');
        submit.setAttribute('style', 'display: none');
        form.appendChild(submit);
        document.body.appendChild(form);

        submit.click();
    }

}

